# All rights reserved.
#
"""RAFIN TxT — encode_id_clan Protocol Buffer Module.

Premium Edition — auto-generated protocol buffer code.
Source: encode_id_clan.proto
"""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
# @@protoc_insertion_point(imports)
_sym_db = _symbol_database.Default()
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x14\x65ncode_id_clan.proto\"(\n\x06MyData\x12\x0e\n\x06\x66ield1\x18\x01 \x01(\r\x12\x0e\n\x06\x66ield2\x18\x02 \x01(\rb\x06proto3')

_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'encode_id_clan_pb2', _globals)
if _descriptor._USE_C_DESCRIPTORS == False:
  DESCRIPTOR._options = None
  _globals['_MYDATA']._serialized_start=24
  _globals['_MYDATA']._serialized_end=64
# @@protoc_insertion_point(module_scope)
